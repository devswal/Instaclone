import React from 'react'
import './postview.css'
function postview() {
  return (
    <div>
         <img id='icon' src={ require('./icon.png') } />
    <a id='title' href="/">Instaclone</a>
    <a href='/Postnew'><img id='camera' src={ require('./camera.png') } /></a>
    <hr id ="rounded"/>
    <div id='post1'>
      <h5 id='postname'>Devansh Singhwal</h5>
      <h7 id="location">Delhi</h7>
      <img id='more' src={ require('./more.png') } />
      <div>
      <img id='space' src={ require('./space.png') } />
      </div>
      <div>
      <img id='heart' src={ require('./heart.png') } />
      <img id='arrow' src={ require('./arrow.png') } />
      </div>
      <div>
        <p id='date'>26 feb 2023</p>
      </div>
      <div>
        <p id='likes'>1765372 Likes</p>
      </div>
      <div>
        <h5 id='caption'>A Magnificent View Of Galaxy</h5>
      </div>
      

    </div>

  </div>
  )
}

export default postview