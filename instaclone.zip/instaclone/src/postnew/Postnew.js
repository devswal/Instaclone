import React from 'react'
import './postnew.css'
function postnew() {
  return (
    <div>
     <img id='icon' src={ require('./icon.png') } />
    <a id='title' href="/">Instaclone</a>
    <img id='camera' src={ require('./camera.png') } />
    <hr id ="rounded"/>
    <div id='upload'>
    <form action="/action_page.php">
  <input id ="cell" type="file"  name="filename"/>
  <input id ="cell"  placeholder='Author'/>
  <input id ="cell"  placeholder='Location'/>
  <input id ="cell"  placeholder='Description'/>
  <input id ="cell"  type="submit"/>
</form>
    </div>
    </div>
    
  )
}

export default postnew