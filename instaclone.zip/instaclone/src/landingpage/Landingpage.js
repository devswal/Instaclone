import React from 'react'
import './landingpage.css'

function Landingpage() {
  return (
    <div>
      <h2 id='name'>INSTACLONE</h2>
      <img id='img1' src={ require('./img11.png') } />
      <a href='./postview'><input id='btn' type = 'button' value='ENTER'/></a>
    </div>
  )
}
export default Landingpage
