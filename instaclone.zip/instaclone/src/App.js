import React from 'react';
import Landingpage from './landingpage/Landingpage';
import Postview from './postview/Postview';
import Postnew from './postnew/Postnew';
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Link
} from "react-router-dom";

function App() {
  return (
    <div>
         <Router>
   <div className="container">
   <Routes>
          <Route exact path="/postnew" element={<Postnew/>}>
            </Route>
            <Route exact path="/postview" element={<Postview/>}>
            </Route>
          <Route exact path="/" element={<Landingpage/>}>
            </Route>
    </Routes>
   </div>
   </Router>
    </div>
  )
}

export default App