import React from 'react'
import Search from './components/Search'
import Ads from './components/ads'
function App() {
  return (
    <div>
      <Search/>
      <Ads/>
    </div>
  )
}

export default App