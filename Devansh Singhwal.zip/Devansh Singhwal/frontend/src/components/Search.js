import React from 'react'
import { useState,useEffect } from 'react';
import axios from 'axios';
import ListGroup from 'react-bootstrap/ListGroup';
import { Link } from 'react-router-dom';
import Form from 'react-bootstrap/Form';
import FormControl from 'react-bootstrap/FormControl';

function Search() {
    const [posts, setPosts] = useState([]); 
    useEffect(() => {
      async function fetchData() {
        const { data } = await axios.get('http://localhost:8000/search');
        setPosts(data.data.result); 
      }
      fetchData();
    }, []);

    const searchPost = async (e) => {
        const searchValue = e.target.value;
        const { data } = await axios.get(`http://localhost:8000/search?search=${searchValue}`);
        // The subset of posts is added to the state that will trigger a re-render of the UI
        console.log(data.data.result.data,data)
        setPosts(data.data.result); 
      };
console.log(posts)
  return (
    <div>
        <h1>Search Page</h1>
        <Form>
          <FormControl
            type="search"
            placeholder="Search"
            className="me-5"
            aria-label="Search"
            onChange={searchPost} // onChange will trigger "search post"
          />
        </Form>
   
        
           {posts && posts.map((post) => {
              return (
                <div className='suggestion-grid'>
                <div className='suggestion-card'>
                {post.name}<br/>{post.headline}<br/>{post.description}

                </div>
               
                </div>
               
              );
            })
          }
          
          
    </div>
  )
}

export default Search