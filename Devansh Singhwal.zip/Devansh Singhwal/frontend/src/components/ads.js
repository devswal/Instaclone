import React from 'react'
import salesforce from './images/salesforce.jpg';
import cotopaxi from './images/cotopaxi.jpg'
import levis from './images/levis.jpg'
import normmac from './images/normMacdonald.jpg'
import valentino from './images/valentino.jpg'
import curology from './images/curology.jpg'
import purple from  './images/purple.jpg'


function Ads() {
  return (
    <div>
        <div className="card-container">
  <div className="card">
    <img src= {salesforce} alt="Card Image"/>
    <h2>Salesforce</h2>
    <h3>Salesforce for Small Business</h3>
    <p>Saleforce provide CRM softwares and is a leading tech company</p>
  </div>
  <div className="card">
    <img src= {levis} alt="Card Image"/>
    <h2>Levis</h2>
    <h3>We like where you're going with this.</h3>
    <p>Relaxed Fit Men's Jeans</p>
  </div>
  <div className="card">
    <img src= {cotopaxi} alt="Card Image"/>
    <h2>cotopaxi</h2>
    <h3>Made With Recycled Plastic</h3>
    <p>Shop Back to School</p>
  </div>
  <div className="card">
    <img src= {normmac} alt="Card Image"/>
    <h2>Netflic</h2>
    <h3>Norm Macdonald's Nothing Special gives one last dose of the late comic</h3>
    <p>The Emmy-nominated Netflix comedy special from the late Norm Macdonald is his last gift to the world of comedy he helped shape.</p>
  </div>
  <div className="card">
    <img src= {valentino} alt="Card Image"/>
    <h2>Valentino</h2>
    <h3>Valentino Hexagonal Metal Frame With Crystal Studs</h3>
    <p>Visit Valentino.com, discover the new products and shop now!</p>
  </div>
  <div className="card">
    <img src= {purple} alt="Card Image"/>
    <h2>Purple</h2>
    <h3>Cooler Summers Start Here</h3>
    <p>Shop Purple products, designed to help you sleep cool.</p>
  </div>
  <div className="card">
    <img src= {curology} alt="Card Image"/>
    <h2>Curology</h2>
    <h3>Dark spots. Breakouts. Rosacea. Dull skin. Fine lines. Our formulas are custom-mixed for YOUR skin concerns.</h3>
    <p>Personalized skincare for dark spots, acne, and more.</p>
  </div>
</div>
    </div>
  )
}

export default Ads